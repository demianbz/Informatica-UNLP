/*
Ejemplo visto en clase de operadores de asignación y operadores unarios
 */
package tema1;


/**
 *
 * @author vsanz
 */
public class Demo02OperadoresUnarios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i = 3; // i vale 3  
        System.out.println(i);
        i++;       // i vale 4
        System.out.println(i);
        i--;      // i vale 3   		   
        System.out.println(i);
    }
    
}
